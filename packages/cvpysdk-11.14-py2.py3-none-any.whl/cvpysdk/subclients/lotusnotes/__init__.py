# -*- coding: utf-8 -*-

# --------------------------------------------------------------------------
# Copyright Commvault Systems, Inc.
# See LICENSE.txt in the project root for
# license information.
# --------------------------------------------------------------------------

"""Initialize Lotus Notes Subclients for the SDK."""

__author__ = 'Commvault Systems Inc.'
