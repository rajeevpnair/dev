# -*- coding: utf-8 -*-

# --------------------------------------------------------------------------
# Copyright Commvault Systems, Inc.
# See LICENSE.txt in the project root for
# license information.
# --------------------------------------------------------------------------

"""Initialize Cloud Apps Backupsets for the SDK."""

__author__ = 'Commvault Systems Inc.'
